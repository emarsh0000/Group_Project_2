<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Process extends CI_Controller 
{
	public function farm()
	{
		$this->
	}

	public function house()
	{
		$this->
	}

	public function cave()
	{
		$this->
	}

	public function casino()
	{
		$this->
	}
	public function gold()
	{
		$this->session->set_userdata();
	}
	public function activity()
	{

	}
}