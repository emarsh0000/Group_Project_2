<html>
<head>
	<title></title>
</head>
<body>
	<form action = '<?php echo base_url('ninjagold/farm')?>'>
		<input type = 'submit'>
	</form>

</body>
</html>