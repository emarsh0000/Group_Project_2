require 'test_helper'

class TimesHelperTest < ActionView::TestCase
end
